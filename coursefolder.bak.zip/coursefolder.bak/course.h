/** 
*@file course.h
*@author Jenna
*@date April 12th, 2022
*@brief Creates a course type and declares the course functions.
*@mainpage Course type and function declaration
*/

#include "student.h"
#include <stdbool.h>
 
/**
*Course type stores a course with the name of the course, course code, students in the course, and the total number of students in the course
*/ 
typedef struct _course 
{
  char name[100]; /**<the name of the course */
  char code[10]; /**<the course code */
  Student *students; /**<the name of the student in the course */
  int total_students; /**<the total number of students in the course */
} Course;

//declares each function made in course.c
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


