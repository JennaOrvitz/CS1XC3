var searchData=
[
  ['name_0',['name',['../struct__course.html#a8a6f7d2171f18b5d13e86913345f381d',1,'_course']]],
  ['num_5fgrades_1',['num_grades',['../struct__student.html#a6592ee968ed2226737f45243e7602636',1,'_student']]]
];
