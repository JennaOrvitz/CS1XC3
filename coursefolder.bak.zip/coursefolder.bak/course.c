/** 
*@file course.c
*@author Jenna
*@date April 12th, 2022
*@brief Manages courses
*@mainpage Courses Program for Students
*/

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
*Enrolls students in a course
*@param course 
*@param student
*@return nothing
*/ 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  //allocates the course and student to the memory
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  //allocates more memory space for the student
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  //adds the new student into the array of all the students
  course->students[course->total_students - 1] = *student;
}
/**
*Prints out the course, the students in it, and the total students in it
*@param course
*@return nothing
*/
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //goes through all the students in the course and prints all of them
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
*Finds the student with the highest average in the course
*@param course
*@return the top student
*/
Student* top_student(Course* course)
{
  //makes sure the course has students enrolled in it
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    //finds the average for each student
    student_average = average(&course->students[i]);
    //if the current student's average if bigger than the previously highest one it becomes the new highest average
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
*Finds which students are passing the course
*@param course 
*@param total_passing number of students passing the course
*@return passing
*/
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //counts the number of students passing (grade higher than 50%)
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //allocates the number of passing students into the memory
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    //adds the students that are passing to an array
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}