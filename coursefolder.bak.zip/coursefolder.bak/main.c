/** 
*@file main.c
*@author Jenna
*@date April 12th, 2022
*@brief Manages students and their courses
*@mainpage Courses Program for Students
*/
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
*Main function
*@param void
*@return 0
*/ 
int main()
{
  //allows random numbers to be created
  srand((unsigned) time(NULL));

//allocates memory for the course MATH101
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

//enrolls students in MATH101
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

//finds the top student in MATH101
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);


//finds the students that are passing MATH101
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}