/** 
*@file student.h
*@author Jenna
*@date April 12th, 2022
*@brief Creates a student type and declares the student functions.
*@mainpage Student type and function declaration
*/ 

/**
*Student type stores a student's first name, last name, their student ID, their grades, and the number of grades they have
*/ 
typedef struct _student 
{ 
  char first_name[50]; /**<the first name of the student */
  char last_name[50]; /**<the last name of the student */
  char id[11]; /**<the student ID */
  double *grades;  /**<the student's grade */
  int num_grades;  /**<the number of grade's the student has */
} Student;

//declares each function made in student.c
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
